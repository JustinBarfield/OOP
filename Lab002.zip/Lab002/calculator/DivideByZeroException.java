package calculator;
public class DivideByZeroException extends CalculatorException {
    public DivideByZeroException() {
        super("Tried to divide by zero.");
    }
}
